
import React, { useState, useMemo, useEffect } from 'react';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Cell, PieChart, Pie } from 'recharts';
import { CashVoucher, AppMode, TaxAnalytics, BusinessInfo } from './types';
import VoucherCard from './components/VoucherCard';
import VoucherForm from './components/VoucherForm';
import DisputeLetterForm from './components/DisputeLetterForm';
import DisputeLetterPreview from './components/DisputeLetterPreview';
import AdsWorkGate from './components/AdsWorkGate';
import PatchNotesModal from './components/PatchNotesModal';

const BrandLogo: React.FC = () => {
  return (
    <div className="flex items-start gap-2 select-none">
      <div className="flex flex-col">
        <div className="flex flex-col leading-none">
          <span className="text-[#4E97D1] font-black text-2xl tracking-tighter drop-shadow-sm uppercase">TUNAI</span>
          <div className="flex items-center">
             <span className="text-[#569D4F] font-black text-2xl tracking-tighter drop-shadow-sm uppercase">CUKAI</span>
             <span className="text-[#F9EB0F] font-black text-2xl tracking-tighter drop-shadow-sm uppercase ml-0.5">MY</span>
          </div>
        </div>
        <div className="mt-1 flex flex-wrap gap-x-1 border-t border-slate-700/50 pt-1">
          <span className="text-[6px] font-bold text-slate-500 uppercase leading-none whitespace-nowrap">CASH VOUCHER SYSTEM</span>
          <span className="text-[6px] font-bold text-emerald-500 uppercase leading-none whitespace-nowrap">| LHDN COMPLIANT</span>
        </div>
      </div>
    </div>
  );
};

const App: React.FC = () => {
  const [vouchers, setVouchers] = useState<CashVoucher[]>([]);
  const [mode, setMode] = useState<AppMode>(AppMode.DASHBOARD);
  const [isUnlocked, setIsUnlocked] = useState(false);
  const [showPatchNotes, setShowPatchNotes] = useState(true);
  const [disputeDraft, setDisputeDraft] = useState<string | null>(null);

  const defaultBusinessInfo: BusinessInfo = useMemo(() => {
    return vouchers.length > 0 && vouchers[0].businessInfo 
      ? vouchers[0].businessInfo 
      : { name: 'My Business Sdn Bhd', address: '123, Jalan Bukit, 50000 Kuala Lumpur' };
  }, [vouchers]);

  const analytics = useMemo<TaxAnalytics>(() => {
    const totalVouchers = vouchers.length;
    const totalAmount = vouchers.reduce((acc, v) => acc + v.amount, 0);
    const estimatedTaxSavings = vouchers.reduce((acc, v) => acc + v.potentialSavings, 0);
    const compliantCount = vouchers.filter(v => v.isCompliant).length;
    const complianceRate = totalVouchers > 0 ? (compliantCount / totalVouchers) * 100 : 0;

    return {
      totalVouchers,
      totalAmount,
      estimatedTaxSavings,
      complianceRate,
      upcomingDeadline: 'April 30, 2026 (BE Form)'
    };
  }, [vouchers]);

  const handleVoucherCreated = (voucher: CashVoucher) => {
    setVouchers([voucher, ...vouchers]);
    setMode(AppMode.DASHBOARD);
  };

  const chartData = useMemo(() => {
    const categories: Record<string, number> = {};
    vouchers.forEach(v => {
      categories[v.category] = (categories[v.category] || 0) + v.amount;
    });
    return Object.entries(categories).map(([name, value]) => ({ name, value }));
  }, [vouchers]);

  const COLORS = ['#10b981', '#3b82f6', '#f59e0b', '#ef4444', '#8b5cf6'];

  return (
    <div className="min-h-screen flex flex-col md:flex-row bg-slate-50 transition-colors duration-500">
      {showPatchNotes && <PatchNotesModal onClose={() => setShowPatchNotes(false)} />}
      <AdsWorkGate isUnlocked={isUnlocked} onUnlock={() => setIsUnlocked(true)} />

      {/* Sidebar - Mobile Friendly Navigation */}
      <aside className="w-full md:w-72 bg-slate-900 text-white flex flex-col shrink-0 border-r border-slate-800 z-10">
        <div className="p-6 border-b border-slate-800 bg-slate-900/50">
          <BrandLogo />
        </div>

        <nav className="p-4 space-y-2 flex-grow overflow-x-auto md:overflow-x-visible whitespace-nowrap md:whitespace-normal flex md:flex-col gap-2 md:gap-2 no-scrollbar">
          <button
            onClick={() => setMode(AppMode.DASHBOARD)}
            className={`flex-1 md:w-full text-left p-3 rounded-lg flex items-center gap-3 transition-all font-bold ${mode === AppMode.DASHBOARD ? 'bg-emerald-600 text-white shadow-lg' : 'text-slate-400 hover:bg-slate-800'}`}
          >
            <i className="fa-solid fa-table-columns"></i> Dashboard
          </button>
          <button
            onClick={() => setMode(AppMode.GENERATE)}
            className={`flex-1 md:w-full text-left p-3 rounded-lg flex items-center gap-3 transition-all font-bold ${mode === AppMode.GENERATE ? 'bg-emerald-600 text-white shadow-lg' : 'text-slate-400 hover:bg-slate-800'}`}
          >
            <i className="fa-solid fa-plus-circle"></i> New Voucher
          </button>
          <button
            onClick={() => { setMode(AppMode.LOST_RECEIPTS_DISPUTE); setDisputeDraft(null); }}
            className={`flex-1 md:w-full text-left p-3 rounded-lg flex items-center gap-3 transition-all font-bold ${mode === AppMode.LOST_RECEIPTS_DISPUTE ? 'bg-red-600 text-white shadow-lg' : 'text-slate-400 hover:bg-slate-800'}`}
          >
            <i className="fa-solid fa-gavel"></i> Disputes
          </button>
          <button
            onClick={() => setMode(AppMode.ANALYTICS)}
            className={`flex-1 md:w-full text-left p-3 rounded-lg flex items-center gap-3 transition-all font-bold ${mode === AppMode.ANALYTICS ? 'bg-emerald-600 text-white shadow-lg' : 'text-slate-400 hover:bg-slate-800'}`}
          >
            <i className="fa-solid fa-chart-line"></i> Insights
          </button>
        </nav>

        <div className="p-4 mt-auto border-t border-slate-800 hidden md:block">
          <div className="bg-slate-800/50 p-3 rounded-xl border border-slate-700">
            <div className="text-[10px] text-slate-500 uppercase font-black mb-2 flex items-center justify-between">
              <span>Patch v.1.12.4</span>
              <button onClick={() => setShowPatchNotes(true)} className="text-emerald-500 hover:underline">Notes</button>
            </div>
            <div className="flex items-center gap-2 text-xs">
              <div className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse"></div>
              <span>Dispute Engine Ready</span>
            </div>
          </div>
        </div>
      </aside>

      {/* Main Content */}
      <main className="flex-grow p-4 md:p-8 max-h-screen overflow-y-auto">
        <header className="flex flex-col md:flex-row md:items-center justify-between gap-4 mb-8">
          <div>
            <h2 className="text-2xl md:text-3xl font-black text-slate-900 tracking-tight uppercase">
              {mode === AppMode.DASHBOARD && 'Operational Ledger'}
              {mode === AppMode.GENERATE && 'Drafting Interface'}
              {mode === AppMode.ANALYTICS && 'Tax Relief Forecasting'}
              {mode === AppMode.LOST_RECEIPTS_DISPUTE && 'Formal Dispute Drafting'}
            </h2>
            <p className="text-slate-500 text-xs md:text-sm">
              {mode === AppMode.DASHBOARD && 'Real-time compliance monitoring for your SME expenses.'}
              {mode === AppMode.GENERATE && 'OCR-enabled document processing for your financial files.'}
              {mode === AppMode.ANALYTICS && 'Projected savings based on LHDN Subsection 34 ITA.'}
              {mode === AppMode.LOST_RECEIPTS_DISPUTE && 'Drafting legal responses for missing receipt audits.'}
            </p>
          </div>

          <div className="flex items-center gap-2 print:hidden">
             <button onClick={() => setMode(AppMode.LOST_RECEIPTS_DISPUTE)} className="bg-red-50 text-red-700 border border-red-200 px-3 md:px-4 py-2 rounded-lg text-xs md:text-sm font-bold shadow-sm hover:bg-red-100 transition-all flex items-center gap-2">
               <i className="fa-solid fa-shield-halved"></i> Audit Dispute
             </button>
             <button onClick={() => setMode(AppMode.GENERATE)} className="bg-emerald-600 text-white px-3 md:px-4 py-2 rounded-lg text-xs md:text-sm font-bold shadow-lg shadow-emerald-200 hover:bg-emerald-700 transition-all flex items-center gap-2">
               <i className="fa-solid fa-plus"></i> New Expense
             </button>
          </div>
        </header>

        {/* Dashboard Summary Stats */}
        {mode !== AppMode.LOST_RECEIPTS_DISPUTE && (
          <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 md:gap-6 mb-8">
            <div className="bg-white p-4 md:p-6 rounded-2xl shadow-sm border border-slate-200/50">
              <div className="text-slate-400 text-[10px] font-black uppercase mb-1">Total Vouchers</div>
              <div className="text-xl md:text-3xl font-black text-slate-900">{analytics.totalVouchers}</div>
            </div>
            <div className="bg-white p-4 md:p-6 rounded-2xl shadow-sm border border-slate-200/50">
              <div className="text-slate-400 text-[10px] font-black uppercase mb-1">Total Volume</div>
              <div className="text-xl md:text-3xl font-black text-slate-900">RM {analytics.totalAmount.toLocaleString()}</div>
            </div>
            <div className="bg-white p-4 md:p-6 rounded-2xl shadow-sm border border-slate-200/50">
              <div className="text-emerald-600 text-[10px] font-black uppercase mb-1">Est. Tax Relief</div>
              <div className="text-xl md:text-3xl font-black text-emerald-700">RM {analytics.estimatedTaxSavings.toLocaleString()}</div>
            </div>
            <div className="bg-white p-4 md:p-6 rounded-2xl shadow-sm border border-slate-200/50">
              <div className="text-slate-400 text-[10px] font-black uppercase mb-1">LHDN Compliance</div>
              <div className="text-xl md:text-3xl font-black text-slate-900">{Math.round(analytics.complianceRate)}%</div>
            </div>
          </div>
        )}

        {/* Main View Switcher */}
        <div className="space-y-8 pb-20 md:pb-0">
          {mode === AppMode.DASHBOARD && (
            <div className="grid grid-cols-1 xl:grid-cols-3 gap-8">
              <div className="xl:col-span-2 space-y-6">
                <div className="flex items-center justify-between px-2">
                  <h3 className="font-black text-[10px] uppercase text-slate-400 tracking-widest flex items-center gap-2">
                    <i className="fa-solid fa-clock-rotate-left text-emerald-500"></i>
                    Recent Activity
                  </h3>
                </div>
                {vouchers.length === 0 ? (
                  <div className="bg-slate-100 border-2 border-dashed border-slate-200 rounded-2xl p-12 text-center">
                    <i className="fa-solid fa-file-invoice-dollar text-4xl text-slate-300 mb-4"></i>
                    <p className="text-slate-500 font-medium">No vouchers created yet.</p>
                    <button 
                      onClick={() => setMode(AppMode.GENERATE)}
                      className="mt-4 text-emerald-600 font-bold hover:underline"
                    >
                      Draft your first one now &rarr;
                    </button>
                  </div>
                ) : (
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    {vouchers.map(v => (
                      <VoucherCard key={v.id} voucher={v} />
                    ))}
                  </div>
                )}
              </div>
              
              <div className="space-y-6">
                 <div className="bg-slate-900 text-white rounded-2xl p-6 shadow-xl relative overflow-hidden border-b-4 border-emerald-500">
                    <h3 className="text-lg font-black uppercase mb-2">Filing Reminder</h3>
                    <p className="text-slate-300 text-xs mb-4">You have {vouchers.length} expenses pending categorization for the upcoming YA 2025 submission.</p>
                    <div className="bg-white/5 p-4 rounded-xl border border-white/10">
                      <div className="text-[10px] uppercase font-black text-emerald-500 mb-1">Deadline</div>
                      <div className="text-xl font-black">{analytics.upcomingDeadline}</div>
                    </div>
                    <button className="w-full mt-6 bg-emerald-600 hover:bg-emerald-500 text-white font-black py-3 rounded-xl transition-all shadow-lg text-xs uppercase tracking-widest">
                      Start Reconciliation
                    </button>
                 </div>
              </div>
            </div>
          )}

          {mode === AppMode.GENERATE && (
            <div className="max-w-7xl mx-auto">
              <VoucherForm onSuccess={handleVoucherCreated} />
            </div>
          )}

          {mode === AppMode.LOST_RECEIPTS_DISPUTE && (
            <div className="max-w-7xl mx-auto">
              {!disputeDraft ? (
                <DisputeLetterForm 
                  businessInfo={defaultBusinessInfo} 
                  onDraftReady={setDisputeDraft}
                />
              ) : (
                <DisputeLetterPreview 
                  content={disputeDraft} 
                  businessInfo={defaultBusinessInfo} 
                  onDownload={() => alert("Simulating PDF Download with TunaiCukaiMY Watermark...")}
                />
              )}
            </div>
          )}

          {mode === AppMode.ANALYTICS && (
            <div className="space-y-8">
               <div className="bg-white p-6 md:p-8 rounded-2xl shadow-sm border border-slate-200">
                 <h3 className="text-lg font-black text-slate-800 mb-6 uppercase">Historical Expense Trend</h3>
                 <div className="h-64">
                   <ResponsiveContainer width="100%" height="100%">
                     <BarChart data={vouchers.map(v => ({ date: v.date, amount: v.amount }))}>
                       <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f1f5f9" />
                       <XAxis dataKey="date" stroke="#94a3b8" fontSize={10} />
                       <YAxis stroke="#94a3b8" fontSize={10} />
                       <Tooltip cursor={{ fill: '#f8fafc' }} contentStyle={{ borderRadius: '12px', border: 'none', boxShadow: '0 10px 15px -3px rgb(0 0 0 / 0.1)' }} />
                       <Bar dataKey="amount" fill="#10b981" radius={[4, 4, 0, 0]} />
                     </BarChart>
                   </ResponsiveContainer>
                 </div>
               </div>
            </div>
          )}
        </div>
      </main>
    </div>
  );
};

export default App;
