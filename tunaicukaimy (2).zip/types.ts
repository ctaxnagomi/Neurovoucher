
export interface BusinessInfo {
  name: string;
  address: string;
  logo?: string;
  regNumber?: string;
}

export interface CashVoucher {
  id: string;
  voucherNumber: string;
  date: string;
  payee: string;
  amount: number;
  description: string;
  category: string;
  isCompliant: boolean;
  complianceNotes: string;
  taxReliefEligible: boolean;
  potentialSavings: number;
  imagePath?: string;
  businessInfo?: BusinessInfo;
  template: 'BUSINESS' | 'PETTY';
}

export interface DisputeLetterData {
  id: string;
  date: string;
  reason: string;
  totalClaim: number;
  vouchersLinked: string[];
  content: string;
  status: 'DRAFT' | 'FINAL';
}

export interface TaxAnalytics {
  totalVouchers: number;
  totalAmount: number;
  estimatedTaxSavings: number;
  complianceRate: number;
  upcomingDeadline: string;
}

export enum AppMode {
  DASHBOARD = 'DASHBOARD',
  GENERATE = 'GENERATE',
  ANALYTICS = 'ANALYTICS',
  LOST_RECEIPTS_DISPUTE = 'LOST_RECEIPTS_DISPUTE',
  SETTINGS = 'SETTINGS'
}

export interface GeminiResponse {
  voucher_draft: Partial<CashVoucher>;
  business_info?: Partial<BusinessInfo>;
  compliance_check: {
    is_compliant: boolean;
    notes: string;
  };
  tax_relief_summary: {
    eligible: boolean;
    savings_est: number;
    reasoning: string;
  };
  recommendations: string[];
}

export interface DisputeResponse {
  letter_content: string;
  legal_references: string[];
  compliance_score: number;
}
