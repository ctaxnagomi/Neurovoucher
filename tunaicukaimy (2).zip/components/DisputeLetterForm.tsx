
import React, { useState } from 'react';
import { draftDisputeLetter } from '../services/geminiService';
import { BusinessInfo } from '../types';

interface DisputeLetterFormProps {
  businessInfo: BusinessInfo;
  onDraftReady: (content: string) => void;
}

const DisputeLetterForm: React.FC<DisputeLetterFormProps> = ({ businessInfo, onDraftReady }) => {
  const [isVerifying, setIsVerifying] = useState(false);
  const [isValidated, setIsValidated] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [reason, setReason] = useState('');
  const [amount, setAmount] = useState<number>(0);
  const [acceptedTerms, setAcceptedTerms] = useState(false);
  const [isDrafting, setIsDrafting] = useState(false);

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    setIsVerifying(true);
    setError(null);

    // Simulate PDF Watermark Verification Logic
    // In a real scenario, we'd use a PDF library to check for specific text/metadata
    setTimeout(() => {
      // Logic: if file name or content (simulated) matches requirement
      if (file.type === 'application/pdf' && (file.name.toLowerCase().includes('cashvoucher') || file.size > 0)) {
        // We assume valid if it's the PDF generated from our tool
        setIsValidated(true);
        setIsVerifying(false);
      } else {
        setError("This is not a valid PDF. Please compile your cash voucher on the 'Cash Voucher' feature then download and upload it here.");
        setIsVerifying(false);
      }
    }, 1500);
  };

  const handleDraft = async () => {
    if (!acceptedTerms) {
      setError("Please accept the Terms of Use before proceeding.");
      return;
    }
    if (!reason || amount <= 0) {
      setError("Please provide a reason and total claim amount.");
      return;
    }

    setIsDrafting(true);
    try {
      const response = await draftDisputeLetter(reason, businessInfo.name, amount);
      onDraftReady(response.letter_content);
    } catch (err) {
      setError("Failed to draft letter. Please check your connection.");
    } finally {
      setIsDrafting(false);
    }
  };

  return (
    <div className="bg-white rounded-2xl shadow-xl p-8 border border-slate-200 max-w-4xl mx-auto">
      <div className="mb-8 border-b pb-6">
        <h2 className="text-2xl font-black text-slate-900 uppercase tracking-tight flex items-center gap-3">
          <i className="fa-solid fa-gavel text-red-600"></i>
          Lost Receipts Disputes Engine
        </h2>
        <p className="text-slate-500 text-sm mt-1">Formal LHDN compliance drafting for missing documentation (v.1.12.4 Patch)</p>
      </div>

      {!isValidated ? (
        <div className="space-y-6 text-center py-12 bg-slate-50 rounded-2xl border-2 border-dashed border-slate-200">
          <div className="mx-auto w-20 h-20 bg-slate-100 rounded-full flex items-center justify-center text-slate-400">
            <i className="fa-solid fa-file-pdf text-4xl"></i>
          </div>
          <div>
            <h3 className="font-bold text-slate-800">Step 1: Upload Validated PDF</h3>
            <p className="text-xs text-slate-500 max-w-xs mx-auto mt-2">
              System only accepts PDFs generated via TunaiCukaiMY with active watermarking.
            </p>
          </div>
          <div className="flex justify-center">
            <label className="bg-slate-900 text-white px-8 py-3 rounded-xl font-bold cursor-pointer hover:bg-slate-800 transition-all flex items-center gap-2">
              <input type="file" className="hidden" accept=".pdf" onChange={handleFileUpload} disabled={isVerifying} />
              {isVerifying ? <i className="fa-solid fa-circle-notch animate-spin"></i> : <i className="fa-solid fa-upload"></i>}
              {isVerifying ? 'Verifying Watermark...' : 'Upload CashVoucher.pdf'}
            </label>
          </div>
        </div>
      ) : (
        <div className="space-y-6 animate-in fade-in duration-500">
          <div className="bg-emerald-50 border-l-4 border-emerald-500 p-4 rounded flex items-center gap-3">
            <i className="fa-solid fa-circle-check text-emerald-600"></i>
            <span className="text-emerald-800 font-bold text-sm uppercase">Watermark Validated: TunaiCukaiMY Original</span>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div className="space-y-2">
              <label className="text-[10px] font-black uppercase text-slate-400">Total Dispute Amount (RM)</label>
              <input 
                type="number" 
                className="w-full p-3 border rounded-xl bg-slate-50 font-bold" 
                placeholder="0.00"
                value={amount}
                onChange={e => setAmount(parseFloat(e.target.value))}
              />
            </div>
            <div className="space-y-2">
              <label className="text-[10px] font-black uppercase text-slate-400">Reason for Dispute</label>
              <select 
                className="w-full p-3 border rounded-xl bg-slate-50 font-bold"
                value={reason}
                onChange={e => setReason(e.target.value)}
              >
                <option value="">Select Reason...</option>
                <option value="Missing physical receipt from vendor">Missing physical receipt</option>
                <option value="Ink faded/Unreadable documentation">Ink faded / Unreadable</option>
                <option value="Vendor closed business/No duplicate available">Vendor closed business</option>
                <option value="Electronic record corruption">Electronic record corruption</option>
              </select>
            </div>
          </div>

          <div className="p-4 bg-slate-50 rounded-xl border border-slate-200">
            <label className="flex items-start gap-3 cursor-pointer">
              <input 
                type="checkbox" 
                className="mt-1 w-4 h-4 rounded text-emerald-600 focus:ring-emerald-500" 
                checked={acceptedTerms}
                onChange={e => setAcceptedTerms(e.target.checked)}
              />
              <span className="text-xs text-slate-600 leading-tight">
                <strong>Terms of Use:</strong> I understand that this draft is based on LHDN guidelines and ITA 1967. TunaiCukaiMY is not responsible for the final audit outcome. I verify that the data provided is truthful.
              </span>
            </label>
          </div>

          <button 
            onClick={handleDraft}
            disabled={isDrafting}
            className="w-full bg-slate-900 text-white py-4 rounded-xl font-black uppercase tracking-widest hover:bg-slate-800 disabled:bg-slate-300 transition-all shadow-xl flex items-center justify-center gap-3"
          >
            {isDrafting ? <i className="fa-solid fa-circle-notch animate-spin"></i> : <i className="fa-solid fa-pen-nib"></i>}
            {isDrafting ? 'Drafting Formal Letter...' : 'Draft Formal Letter'}
          </button>
        </div>
      )}

      {error && (
        <div className="mt-6 p-4 bg-red-50 text-red-700 rounded-xl border border-red-100 flex items-start gap-3 text-sm animate-in slide-in-from-top-2">
          <i className="fa-solid fa-circle-xmark mt-1"></i>
          <p className="font-medium">{error}</p>
        </div>
      )}
    </div>
  );
};

export default DisputeLetterForm;
