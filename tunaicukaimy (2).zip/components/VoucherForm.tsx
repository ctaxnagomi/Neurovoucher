
import React, { useState, useRef } from 'react';
import { analyzeVoucherInput } from '../services/geminiService';
import { CashVoucher, BusinessInfo } from '../types';
import VoucherPreview from './VoucherPreview';

interface VoucherFormProps {
  onSuccess: (voucher: CashVoucher) => void;
}

const VoucherForm: React.FC<VoucherFormProps> = ({ onSuccess }) => {
  const [prompt, setPrompt] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [showPreview, setShowPreview] = useState(false);
  const [selectedTemplate, setSelectedTemplate] = useState<'BUSINESS' | 'PETTY'>('BUSINESS');
  
  const [businessInfo, setBusinessInfo] = useState<BusinessInfo>({
    name: '',
    address: '',
    regNumber: '',
    logo: ''
  });

  const [draftVoucher, setDraftVoucher] = useState<Partial<CashVoucher>>({});
  const logoInputRef = useRef<HTMLInputElement>(null);

  const handleGenerate = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!prompt.trim()) return;
    processInput(prompt);
  };

  const processInput = async (input: string | { base64: string, mimeType: string }) => {
    setIsLoading(true);
    setError(null);
    try {
      const result = await analyzeVoucherInput(input);
      setDraftVoucher(result.voucher_draft);
      if (result.business_info) {
        setBusinessInfo(prev => ({
          ...prev,
          name: result.business_info?.name || prev.name,
          address: result.business_info?.address || prev.address,
          regNumber: result.business_info?.regNumber || prev.regNumber,
        }));
      }
      setShowPreview(true);
      setPrompt('');
    } catch (err) {
      setError('Failed to process input. Please try again.');
      console.error(err);
    } finally {
      setIsLoading(false);
    }
  };

  const handleFileUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = async () => {
      const base64 = (reader.result as string).split(',')[1];
      processInput({ base64, mimeType: file.type });
    };
    reader.readAsDataURL(file);
  };

  const handleLogoUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onload = () => {
        setBusinessInfo(prev => ({ ...prev, logo: reader.result as string }));
      };
      reader.readAsDataURL(file);
    }
  };

  const finalizeVoucher = () => {
    if (!draftVoucher.amount || !draftVoucher.payee) {
       setError("Missing amount or payee. Please edit first.");
       return;
    }
    const finalVoucher: CashVoucher = {
      id: Math.random().toString(36).substr(2, 9),
      voucherNumber: draftVoucher.voucherNumber || `CV-${Date.now().toString().slice(-4)}`,
      date: draftVoucher.date || new Date().toISOString().split('T')[0],
      payee: draftVoucher.payee || 'Unknown',
      amount: draftVoucher.amount || 0,
      description: draftVoucher.description || 'No description',
      category: draftVoucher.category || 'General',
      isCompliant: true,
      complianceNotes: '',
      taxReliefEligible: true,
      potentialSavings: (draftVoucher.amount || 0) * 0.24,
      businessInfo: businessInfo,
      template: selectedTemplate
    };
    onSuccess(finalVoucher);
    setShowPreview(false);
  };

  if (showPreview) {
    return (
      <div className="space-y-8 animate-in fade-in slide-in-from-bottom-4 duration-500">
        <div className="bg-amber-50 border-l-4 border-amber-500 p-4 rounded shadow-sm flex items-start gap-3">
           <i className="fa-solid fa-triangle-exclamation text-amber-600 mt-1"></i>
           <div>
             <p className="text-amber-900 font-bold text-sm">Please verify all scanned details below.</p>
             <p className="text-amber-800 text-xs">OCR errors can occur. Ensure Company Name, Address, and Amount are correct before saving.</p>
           </div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
           {/* Editor Side */}
           <div className="bg-white rounded-2xl shadow-xl p-8 border border-slate-200 space-y-4 max-h-[80vh] overflow-y-auto sticky top-4">
              <h3 className="font-black text-slate-800 uppercase tracking-tight flex items-center gap-2">
                <i className="fa-solid fa-pen-to-square text-emerald-600"></i>
                Review & Edit
              </h3>

              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-1">
                  <label className="text-[10px] font-black uppercase text-slate-500">Template</label>
                  <select 
                    value={selectedTemplate} 
                    onChange={e => setSelectedTemplate(e.target.value as any)}
                    className="w-full p-2 border rounded-lg bg-slate-50 text-sm font-bold"
                  >
                    <option value="BUSINESS">Business (IPES Style)</option>
                    <option value="PETTY">Petty Cash Style</option>
                  </select>
                </div>
                <div className="space-y-1">
                  <label className="text-[10px] font-black uppercase text-slate-500">Logo</label>
                  <button 
                    onClick={() => logoInputRef.current?.click()}
                    className="w-full p-2 border border-emerald-300 text-emerald-700 rounded-lg bg-emerald-50 text-[10px] font-bold uppercase hover:bg-emerald-100 transition-colors"
                  >
                    {businessInfo.logo ? 'Change Logo' : 'Upload Logo'}
                  </button>
                  <input ref={logoInputRef} type="file" hidden accept="image/*" onChange={handleLogoUpload} />
                </div>
              </div>

              <div className="space-y-3 pt-4 border-t">
                <h4 className="text-xs font-black text-slate-400 uppercase">Company Details</h4>
                <div className="space-y-1">
                  <input 
                    className="w-full p-2 border rounded bg-slate-50 text-sm font-bold" 
                    placeholder="Company Name"
                    value={businessInfo.name}
                    onChange={e => setBusinessInfo({...businessInfo, name: e.target.value})}
                  />
                </div>
                <div className="space-y-1">
                  <textarea 
                    className="w-full p-2 border rounded bg-slate-50 text-sm h-16 resize-none" 
                    placeholder="Company Address"
                    value={businessInfo.address}
                    onChange={e => setBusinessInfo({...businessInfo, address: e.target.value})}
                  />
                </div>
              </div>

              <div className="space-y-3 pt-4 border-t">
                <h4 className="text-xs font-black text-slate-400 uppercase">Voucher Details</h4>
                <div className="grid grid-cols-2 gap-2">
                  <input 
                    className="p-2 border rounded bg-slate-50 text-sm font-bold" 
                    placeholder="Voucher #" 
                    value={draftVoucher.voucherNumber}
                    onChange={e => setDraftVoucher({...draftVoucher, voucherNumber: e.target.value})}
                  />
                  <input 
                    type="date"
                    className="p-2 border rounded bg-slate-50 text-sm font-bold" 
                    value={draftVoucher.date}
                    onChange={e => setDraftVoucher({...draftVoucher, date: e.target.value})}
                  />
                </div>
                <input 
                  className="w-full p-2 border rounded bg-slate-50 text-sm font-bold" 
                  placeholder="Payee"
                  value={draftVoucher.payee}
                  onChange={e => setDraftVoucher({...draftVoucher, payee: e.target.value})}
                />
                <input 
                  type="number"
                  className="w-full p-2 border rounded bg-slate-50 text-sm font-bold" 
                  placeholder="Amount RM"
                  value={draftVoucher.amount}
                  onChange={e => setDraftVoucher({...draftVoucher, amount: parseFloat(e.target.value) || 0})}
                />
                <textarea 
                  className="w-full p-2 border rounded bg-slate-50 text-sm h-20 resize-none" 
                  placeholder="Description"
                  value={draftVoucher.description}
                  onChange={e => setDraftVoucher({...draftVoucher, description: e.target.value})}
                />
              </div>

              <div className="pt-6 flex gap-3">
                <button 
                  onClick={() => setShowPreview(false)}
                  className="flex-1 py-3 px-4 rounded-xl border-2 border-slate-200 text-slate-600 font-black text-xs uppercase hover:bg-slate-50 transition-colors"
                >
                  Discard
                </button>
                <button 
                  onClick={finalizeVoucher}
                  className="flex-[2] py-3 px-4 rounded-xl bg-emerald-600 text-white font-black text-xs uppercase shadow-lg shadow-emerald-200 hover:bg-emerald-700 transition-all active:scale-95"
                >
                  Confirm & Finalize
                </button>
              </div>
           </div>

           {/* Preview Side */}
           <div className="lg:sticky lg:top-4 h-fit">
              <VoucherPreview voucher={{...draftVoucher as any, businessInfo, template: selectedTemplate}} />
           </div>
        </div>
      </div>
    );
  }

  return (
    <div className="bg-white rounded-2xl shadow-xl p-8 border border-slate-200">
      <div className="mb-6">
        <h2 className="text-xl font-black text-slate-800 uppercase tracking-tight">Voucher Draft Engine</h2>
        <p className="text-slate-500 text-sm">Upload documentation or describe transaction for smart LHDN voucher generation.</p>
      </div>

      <form onSubmit={handleGenerate} className="space-y-6">
        <div className="space-y-2">
          <label className="text-[10px] font-black text-slate-400 uppercase tracking-wider">Transaction Narrative</label>
          <textarea
            value={prompt}
            onChange={(e) => setPrompt(e.target.value)}
            className="w-full h-32 p-4 bg-slate-50 border border-slate-200 rounded-xl focus:ring-2 focus:ring-emerald-500 focus:border-emerald-500 transition-all resize-none outline-none font-medium"
            placeholder="Describe the payment details, payee, and items purchased..."
          ></textarea>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <button
            type="submit"
            disabled={isLoading || !prompt.trim()}
            className={`py-4 rounded-xl font-black uppercase text-xs tracking-widest flex items-center justify-center gap-2 transition-all shadow-lg ${
              isLoading || !prompt.trim() 
                ? 'bg-slate-300 text-slate-500 cursor-not-allowed shadow-none' 
                : 'bg-emerald-600 text-white hover:bg-emerald-700 active:scale-95 shadow-emerald-200/50'
            }`}
          >
            {isLoading ? (
              <i className="fa-solid fa-circle-notch animate-spin text-xl"></i>
            ) : (
              <><i className="fa-solid fa-sparkles"></i> Generate Draft</>
            )}
          </button>

          <div className="relative">
            <input
              type="file"
              id="doc-upload"
              className="hidden"
              accept="image/png, image/jpeg, application/pdf"
              onChange={handleFileUpload}
              disabled={isLoading}
            />
            <label
              htmlFor="doc-upload"
              className={`w-full py-4 rounded-xl border-2 border-dashed font-black uppercase text-xs tracking-widest flex items-center justify-center gap-2 transition-all cursor-pointer ${
                isLoading 
                  ? 'bg-slate-50 border-slate-200 text-slate-400 cursor-not-allowed' 
                  : 'bg-slate-50 border-emerald-300 text-emerald-700 hover:bg-emerald-50 active:scale-95 shadow-lg shadow-emerald-100/50'
              }`}
            >
              <i className="fa-solid fa-file-invoice"></i> OCR: PDF/PNG/JPG
            </label>
          </div>
        </div>
      </form>

      {error && (
        <div className="mt-4 p-3 bg-red-50 text-red-600 rounded-lg text-sm border border-red-100 flex items-center gap-2 animate-bounce">
          <i className="fa-solid fa-circle-exclamation"></i>
          {error}
        </div>
      )}
    </div>
  );
};

export default VoucherForm;
