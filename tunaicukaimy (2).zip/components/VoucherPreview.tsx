
import React from 'react';
import { CashVoucher } from '../types';

interface VoucherPreviewProps {
  voucher: CashVoucher;
}

const VoucherPreview: React.FC<VoucherPreviewProps> = ({ voucher }) => {
  const isBusiness = voucher.template === 'BUSINESS';

  return (
    <div className="bg-white p-8 shadow-2xl border border-slate-300 mx-auto max-w-[800px] relative font-serif text-slate-900 overflow-hidden print:shadow-none print:border-none">
      {/* Watermark: 2% size of container width is roughly text-[8px]-text-[10px], 15% opacity */}
      <div className="absolute bottom-4 left-1/2 -translate-x-1/2 pointer-events-none select-none opacity-15 text-[2%] uppercase font-black tracking-[0.2em] text-slate-400">
        TunaiCukaiMY
      </div>

      {isBusiness ? (
        <div className="space-y-6">
          {/* Business Template Header (IPES Style) */}
          <div className="flex justify-between items-start border-b-2 border-slate-900 pb-4">
            <div className="flex gap-4 items-center">
              {voucher.businessInfo?.logo ? (
                <img src={voucher.businessInfo.logo} className="w-24 h-24 object-contain border p-1 rounded" alt="Logo" />
              ) : (
                <div className="w-20 h-20 bg-slate-100 border-2 border-dashed border-slate-300 flex items-center justify-center text-[10px] text-slate-400">No Logo</div>
              )}
              <div className="max-w-md">
                <h1 className="text-xl font-black uppercase leading-tight">{voucher.businessInfo?.name || 'Your Company Name Sdn Bhd'}</h1>
                <p className="text-[10px] leading-tight whitespace-pre-line text-slate-700 mt-1">
                  {voucher.businessInfo?.address || 'Your Business Address\nPostcode, City, State'}
                </p>
                {voucher.businessInfo?.regNumber && <p className="text-[10px] font-bold mt-1">({voucher.businessInfo.regNumber})</p>}
              </div>
            </div>
            <div className="text-right">
              <h2 className="text-2xl font-black uppercase tracking-widest text-slate-800">Payment Voucher</h2>
              <div className="mt-2 text-sm">
                <span className="font-bold">Date :</span> 
                <span className="border-b border-slate-400 px-4 inline-block min-w-[120px] text-center">{voucher.date}</span>
              </div>
              <div className="mt-1 text-sm">
                <span className="font-bold">Voucher No :</span> 
                <span className="border-b border-slate-400 px-4 inline-block min-w-[120px] text-center">{voucher.voucherNumber}</span>
              </div>
            </div>
          </div>

          <div className="mt-4">
            <div className="flex gap-2 items-center mb-4">
              <span className="font-bold text-sm uppercase shrink-0">Pay To :</span>
              <div className="border-b border-slate-900 flex-grow px-2 py-0.5 font-bold italic">{voucher.payee}</div>
            </div>

            <table className="w-full border-collapse border-2 border-slate-900 text-sm">
              <thead>
                <tr className="bg-slate-50">
                  <th className="border-2 border-slate-900 p-2 text-left uppercase font-bold w-3/4">Particulars of Payment</th>
                  <th className="border-2 border-slate-900 p-2 text-center uppercase font-bold">Amount (RM)</th>
                </tr>
              </thead>
              <tbody>
                <tr className="h-48 align-top">
                  <td className="border-2 border-slate-900 p-4 font-medium leading-relaxed">
                    {voucher.description}
                  </td>
                  <td className="border-2 border-slate-900 p-4 text-center text-lg font-black bg-slate-50/50">
                    {voucher.amount.toFixed(2)}
                  </td>
                </tr>
                <tr className="bg-slate-100">
                  <td className="border-2 border-slate-900 p-2 text-right font-black uppercase">Total RM</td>
                  <td className="border-2 border-slate-900 p-2 text-center font-black text-xl">{voucher.amount.toFixed(2)}</td>
                </tr>
              </tbody>
            </table>
          </div>

          {/* Footer signatures */}
          <div className="grid grid-cols-3 gap-8 pt-12 text-center text-[10px] font-bold uppercase">
             <div className="space-y-2">
               <div className="border-t border-dotted border-slate-900 pt-1">Prepared By</div>
             </div>
             <div className="space-y-2">
               <div className="border-t border-dotted border-slate-900 pt-1">Approved By</div>
             </div>
             <div className="space-y-2">
               <div className="border-t border-dotted border-slate-900 pt-1">Received By</div>
             </div>
          </div>
        </div>
      ) : (
        <div className="space-y-6">
          {/* Petty Cash Template (Orange County Style) */}
          <div className="text-center space-y-1">
            <h1 className="text-2xl font-black uppercase">Petty Cash Voucher</h1>
            <p className="text-[10px] italic">(Original Itemized Receipt Must Be Attached)</p>
          </div>

          <div className="space-y-4 text-xs font-bold uppercase pt-4">
             <div className="grid grid-cols-2 gap-4">
               <div className="flex gap-2 border-b border-slate-300 pb-1">
                 <span className="shrink-0 w-16">Date:</span>
                 <span className="text-slate-700 italic">{voucher.date}</span>
               </div>
               <div className="flex gap-2 border-b border-slate-300 pb-1">
                 <span className="shrink-0 w-16">No:</span>
                 <span className="text-slate-700 italic">{voucher.voucherNumber}</span>
               </div>
             </div>
             <div className="flex gap-2 border-b border-slate-300 pb-1">
                <span className="shrink-0 w-16">Payee:</span>
                <span className="text-slate-700 italic">{voucher.payee}</span>
             </div>
             <div className="flex gap-2 border-b border-slate-300 pb-1">
                <span className="shrink-0 w-32">Purchased From:</span>
                <span className="text-slate-700 italic">{voucher.category} Store / Vendor</span>
             </div>
          </div>

          <table className="w-full border-2 border-slate-900 text-xs">
            <thead>
              <tr className="bg-slate-100 border-b-2 border-slate-900">
                <th className="p-2 border-r-2 border-slate-900 uppercase">Item Description</th>
                <th className="p-2 w-32 uppercase text-center">Amount</th>
              </tr>
            </thead>
            <tbody>
              <tr className="h-40 align-top">
                <td className="p-4 border-r-2 border-slate-900">{voucher.description}</td>
                <td className="p-4 text-center font-black text-sm">RM {voucher.amount.toFixed(2)}</td>
              </tr>
              <tr className="border-t-2 border-slate-900">
                <td className="p-2 text-right border-r-2 border-slate-900 uppercase font-black">Sub Total</td>
                <td className="p-2 text-center font-black">RM {voucher.amount.toFixed(2)}</td>
              </tr>
              <tr className="border-t border-slate-300">
                <td className="p-2 text-right border-r-2 border-slate-900 uppercase font-black">Tax</td>
                <td className="p-2 text-center">0.00</td>
              </tr>
              <tr className="border-t-2 border-slate-900 bg-slate-50">
                <td className="p-2 text-right border-r-2 border-slate-900 uppercase font-black text-sm">Total</td>
                <td className="p-2 text-center font-black text-sm">RM {voucher.amount.toFixed(2)}</td>
              </tr>
            </tbody>
          </table>

          <p className="text-[8px] italic border-t pt-2 border-slate-300">
            I certify that the item purchased and received was a legal expenditure within the guidelines of TunaiCukaiMY and remained property of the designated entity.
          </p>

          <div className="pt-8 flex justify-between items-end">
             <div className="w-1/2 border-t border-slate-900 pt-1 text-[8px] font-bold uppercase">Signature of Recipient</div>
             <div className="flex gap-4 text-[7px] font-black uppercase text-slate-500">
               <span className="border px-1">WHITE: ACCOUNTING COPY</span>
               <span className="border px-1">GREEN: SITE COPY</span>
             </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default VoucherPreview;
