
import React, { useState, useEffect } from 'react';

interface AdsWorkGateProps {
  onUnlock: () => void;
  isUnlocked: boolean;
}

const AdsWorkGate: React.FC<AdsWorkGateProps> = ({ onUnlock, isUnlocked }) => {
  const [timeLeft, setTimeLeft] = useState(15);
  const [isWatching, setIsWatching] = useState(false);

  useEffect(() => {
    let timer: any;
    if (isWatching && timeLeft > 0) {
      timer = setTimeout(() => setTimeLeft(prev => prev - 1), 1000);
    } else if (isWatching && timeLeft === 0) {
      setIsWatching(false);
      onUnlock();
    }
    return () => clearTimeout(timer);
  }, [isWatching, timeLeft, onUnlock]);

  if (isUnlocked) return null;

  const videoId = "Z15Y0hjtsm0";
  const embedUrl = `https://www.youtube.com/embed/${videoId}?autoplay=1&mute=1&loop=1&playlist=${videoId}&controls=0&rel=0&iv_load_policy=3&modestbranding=1`;

  return (
    <div className="fixed inset-0 z-[100] bg-slate-900/95 flex items-center justify-center p-4 backdrop-blur-md">
      <div className="bg-white rounded-3xl shadow-2xl max-w-xl w-full overflow-hidden border-t-4 border-emerald-500 flex flex-col">
        <div className="p-8 text-center">
          <div className="mb-4">
            <div className="w-16 h-16 bg-emerald-100 rounded-full flex items-center justify-center mx-auto mb-4">
              <i className="fa-solid fa-rectangle-ad text-3xl text-emerald-600"></i>
            </div>
            <h2 className="text-2xl font-black text-slate-800 uppercase tracking-tight">AdsWork Authorization</h2>
            <p className="text-slate-500 mt-2 text-sm">To use the Smart LHDN engine for free, please watch this 15-second segment.</p>
          </div>

          {!isWatching ? (
            <button
              onClick={() => setIsWatching(true)}
              className="w-full bg-emerald-600 hover:bg-emerald-700 text-white font-black py-4 rounded-2xl transition-all flex items-center justify-center gap-3 shadow-lg shadow-emerald-200 uppercase tracking-widest text-xs"
            >
              <i className="fa-solid fa-play"></i>
              Watch & Unlock (15s)
            </button>
          ) : (
            <div className="space-y-6">
              <div className="w-full aspect-video bg-black rounded-2xl overflow-hidden shadow-inner relative group border border-slate-200">
                <iframe
                  className="w-full h-full pointer-events-none"
                  src={embedUrl}
                  title="AdsWork Ad"
                  frameBorder="0"
                  allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
                  allowFullScreen
                ></iframe>
                <div className="absolute top-4 right-4 bg-black/60 backdrop-blur-md text-white px-3 py-1 rounded-full text-[10px] font-bold uppercase tracking-widest border border-white/20">
                  Ad Content
                </div>
              </div>
              
              <div className="relative pt-1 px-4">
                <div className="flex mb-2 items-center justify-between">
                  <div>
                    <span className="text-[10px] font-black inline-block py-1 px-3 uppercase rounded-full text-emerald-700 bg-emerald-100 tracking-widest">
                      Unlocking TunaiCukai Engine
                    </span>
                  </div>
                  <div className="text-right">
                    <span className="text-xs font-black text-emerald-600 font-mono">
                      {timeLeft}s
                    </span>
                  </div>
                </div>
                <div className="overflow-hidden h-3 mb-4 text-xs flex rounded-full bg-slate-100 border border-slate-200">
                  <div 
                    style={{ width: `${((15 - timeLeft) / 15) * 100}%` }} 
                    className="shadow-none flex flex-col text-center whitespace-nowrap text-white justify-center bg-emerald-500 transition-all duration-1000 ease-linear"
                  ></div>
                </div>
              </div>
            </div>
          )}

          <div className="mt-6 border-t pt-6 flex items-center justify-center">
            <p className="text-[10px] text-slate-400 uppercase font-bold">
              Powered by AdsWork & DeckerGUI Ecosystem
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};

export default AdsWorkGate;
