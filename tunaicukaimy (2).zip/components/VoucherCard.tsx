
import React from 'react';
import { CashVoucher } from '../types';

interface VoucherCardProps {
  voucher: CashVoucher;
}

const VoucherCard: React.FC<VoucherCardProps> = ({ voucher }) => {
  return (
    <div className="bg-white border border-slate-200 rounded-xl overflow-hidden shadow-sm hover:shadow-md transition-shadow">
      <div className="bg-emerald-600 p-4 flex justify-between items-center text-white">
        <div className="font-bold text-lg uppercase tracking-wider">Cash Voucher</div>
        <div className="text-xs bg-white/20 px-2 py-1 rounded">No: {voucher.voucherNumber}</div>
      </div>
      
      <div className="p-6 space-y-4">
        <div className="flex justify-between border-b pb-2">
          <span className="text-slate-500 text-sm font-medium uppercase">Date</span>
          <span className="text-slate-800 font-semibold">{voucher.date}</span>
        </div>
        
        <div className="flex justify-between border-b pb-2">
          <span className="text-slate-500 text-sm font-medium uppercase">Payee</span>
          <span className="text-slate-800 font-semibold">{voucher.payee}</span>
        </div>
        
        <div className="flex justify-between border-b pb-2">
          <span className="text-slate-500 text-sm font-medium uppercase">Amount</span>
          <span className="text-2xl font-bold text-emerald-700">RM {voucher.amount.toFixed(2)}</span>
        </div>
        
        <div className="pt-2">
          <span className="text-slate-500 text-sm font-medium uppercase block mb-1">Description</span>
          <p className="text-slate-700 text-sm italic">{voucher.description}</p>
        </div>

        <div className="pt-4 flex items-center justify-between border-t border-slate-100">
          <div className="flex gap-2">
            {voucher.isCompliant ? (
              <span className="flex items-center gap-1 text-[10px] font-bold bg-emerald-100 text-emerald-700 px-2 py-1 rounded-full border border-emerald-200 uppercase">
                <i className="fa-solid fa-circle-check"></i> LHDN Compliant
              </span>
            ) : (
              <span className="flex items-center gap-1 text-[10px] font-bold bg-red-100 text-red-700 px-2 py-1 rounded-full border border-red-200 uppercase">
                <i className="fa-solid fa-circle-exclamation"></i> Revision Needed
              </span>
            )}
            
            {voucher.taxReliefEligible && (
              <span className="flex items-center gap-1 text-[10px] font-bold bg-amber-100 text-amber-700 px-2 py-1 rounded-full border border-amber-200 uppercase">
                <i className="fa-solid fa-piggy-bank"></i> Relief Available
              </span>
            )}
          </div>
          <div className="text-[10px] text-slate-400 font-mono">
            {voucher.id.substring(0, 8)}
          </div>
        </div>
      </div>
    </div>
  );
};

export default VoucherCard;
