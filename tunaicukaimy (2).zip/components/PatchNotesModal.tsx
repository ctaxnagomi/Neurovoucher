
import React from 'react';

interface PatchNotesModalProps {
  onClose: () => void;
}

const PatchNotesModal: React.FC<PatchNotesModalProps> = ({ onClose }) => {
  return (
    <div className="fixed inset-0 z-[110] bg-slate-950/80 flex items-center justify-center p-4 backdrop-blur-sm transition-opacity duration-300">
      <div className="bg-white w-full max-w-lg rounded-3xl shadow-2xl overflow-hidden animate-in fade-in zoom-in-95 duration-300">
        <div className="bg-slate-900 p-8 text-white relative">
          <div className="absolute top-0 right-0 p-4">
            <span className="bg-emerald-500 text-[10px] font-black px-3 py-1 rounded-full uppercase tracking-tighter shadow-lg">LATEST UPDATE</span>
          </div>
          <h2 className="text-3xl font-black tracking-tighter uppercase leading-none italic">
            TunaiCukai<span className="text-emerald-500">MY</span>
          </h2>
          <p className="text-slate-400 font-bold text-xs mt-2 uppercase tracking-widest">Version 1.12.4 • Official Patch Notes</p>
        </div>

        <div className="p-8 space-y-6 max-h-[60vh] overflow-y-auto bg-slate-50/50">
          <section className="space-y-4">
            <h3 className="text-xs font-black text-slate-400 uppercase tracking-widest border-b border-slate-200 pb-2">New Core Features</h3>
            
            <div className="flex gap-4">
              <div className="w-10 h-10 shrink-0 bg-red-100 text-red-600 rounded-xl flex items-center justify-center shadow-sm">
                <i className="fa-solid fa-gavel text-lg"></i>
              </div>
              <div className="space-y-1">
                <h4 className="font-black text-slate-800 text-sm uppercase">Lost Receipts Dispute Engine</h4>
                <p className="text-xs text-slate-500 leading-relaxed">Formal letter drafting specifically for missing documentation audits, integrated with LHDN Public Ruling No. 5/2021.</p>
              </div>
            </div>

            <div className="flex gap-4">
              <div className="w-10 h-10 shrink-0 bg-emerald-100 text-emerald-600 rounded-xl flex items-center justify-center shadow-sm">
                <i className="fa-solid fa-file-signature text-lg"></i>
              </div>
              <div className="space-y-1">
                <h4 className="font-black text-slate-800 text-sm uppercase">Multi-Template Voucher System</h4>
                <p className="text-xs text-slate-500 leading-relaxed">Choose between high-fidelity "Business" (IPES Style) and "Petty Cash" layouts for professional financial recording.</p>
              </div>
            </div>

            <div className="flex gap-4">
              <div className="w-10 h-10 shrink-0 bg-blue-100 text-blue-600 rounded-xl flex items-center justify-center shadow-sm">
                <i className="fa-solid fa-shield-halved text-lg"></i>
              </div>
              <div className="space-y-1">
                <h4 className="font-black text-slate-800 text-sm uppercase">Secure Watermarking</h4>
                <p className="text-xs text-slate-500 leading-relaxed">Automated 15% opacity watermark on all generated PDFs to ensure validity for internal and external audits.</p>
              </div>
            </div>
          </section>

          <section className="space-y-4">
            <h3 className="text-xs font-black text-slate-400 uppercase tracking-widest border-b border-slate-200 pb-2">Improvements</h3>
            <ul className="space-y-3">
              <li className="flex items-center gap-3 text-xs font-bold text-slate-700">
                <i className="fa-solid fa-check text-emerald-500"></i>
                Advanced OCR Scanning for Letterheads & Addresses
              </li>
              <li className="flex items-center gap-3 text-xs font-bold text-slate-700">
                <i className="fa-solid fa-check text-emerald-500"></i>
                ITA 1967 Paragraph 82(1) Reference Integration
              </li>
              <li className="flex items-center gap-3 text-xs font-bold text-slate-700">
                <i className="fa-solid fa-check text-emerald-500"></i>
                Mobile-Optimized Touch Interfaces
              </li>
              <li className="flex items-center gap-3 text-xs font-bold text-slate-700">
                <i className="fa-solid fa-check text-emerald-500"></i>
                AdsWork Authorization Loop Refinement
              </li>
            </ul>
          </section>
        </div>

        <div className="p-6 bg-white border-t border-slate-100">
          <button 
            onClick={onClose}
            className="w-full bg-slate-900 text-white py-4 rounded-2xl font-black uppercase text-xs tracking-widest shadow-xl active:scale-95 transition-all hover:bg-slate-800"
          >
            Enter System
          </button>
        </div>
      </div>
    </div>
  );
};

export default PatchNotesModal;
