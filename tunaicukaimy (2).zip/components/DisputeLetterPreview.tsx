
import React from 'react';
import { BusinessInfo } from '../types';

interface DisputeLetterPreviewProps {
  content: string;
  businessInfo: BusinessInfo;
  onDownload: () => void;
}

const DisputeLetterPreview: React.FC<DisputeLetterPreviewProps> = ({ content, businessInfo, onDownload }) => {
  return (
    <div className="space-y-8 animate-in fade-in zoom-in-95 duration-500">
      <div className="flex justify-end gap-3 print:hidden">
        <button 
          onClick={() => window.print()}
          className="bg-white border-2 border-slate-200 px-6 py-2 rounded-xl font-bold text-slate-700 hover:bg-slate-50 flex items-center gap-2"
        >
          <i className="fa-solid fa-print"></i> Print Letter
        </button>
        <button 
          onClick={onDownload}
          className="bg-slate-900 text-white px-6 py-2 rounded-xl font-bold hover:bg-slate-800 flex items-center gap-2 shadow-lg"
        >
          <i className="fa-solid fa-file-pdf"></i> Download Official PDF
        </button>
      </div>

      <div className="bg-white p-12 shadow-2xl mx-auto w-full max-w-[210mm] min-h-[297mm] font-serif text-slate-900 relative print:shadow-none print:m-0">
        {/* Header Logo Integration */}
        {businessInfo.logo && (
          <div className="mb-6 flex justify-start">
            <img src={businessInfo.logo} className="h-16 object-contain grayscale" alt="Logo" />
          </div>
        )}

        {/* Business Address */}
        <div className="mb-10 text-sm">
          <h1 className="font-bold text-lg uppercase">{businessInfo.name}</h1>
          <p className="whitespace-pre-line text-slate-700">{businessInfo.address}</p>
          {businessInfo.regNumber && <p className="mt-1 font-bold">({businessInfo.regNumber})</p>}
        </div>

        <div className="border-t border-slate-300 mb-10"></div>

        {/* Letter Content */}
        <div className="text-justify leading-relaxed whitespace-pre-line text-[12pt]">
          {content}
        </div>

        {/* Signature Container */}
        <div className="mt-20 flex justify-between items-end">
          <div className="space-y-16">
            <p className="text-sm font-bold">Sincerely,</p>
            <div className="w-48 border-b-2 border-slate-900"></div>
            <div>
              <p className="font-bold uppercase text-sm">{businessInfo.name}</p>
              <p className="text-xs text-slate-500">Authorized Personnel</p>
            </div>
          </div>
          <div className="text-right italic text-[10px] text-slate-300">
            TunaiCukaiMY Automated Draft v.1.12.4
          </div>
        </div>

        {/* Watermark at bottom */}
        <div className="absolute bottom-4 left-1/2 -translate-x-1/2 pointer-events-none select-none opacity-15 text-[2%] uppercase font-black tracking-widest text-slate-400">
          TunaiCukaiMY
        </div>
      </div>
    </div>
  );
};

export default DisputeLetterPreview;
