
import { GoogleGenAI, Type, GenerateContentResponse } from "@google/genai";
import { GeminiResponse, DisputeResponse } from "../types";

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

const SYSTEM_INSTRUCTION = `You are the TunaiCukaiMY Smart Engine. 
Expert in Malaysian tax (LHDN/HASiL) and Public Rulings.
Task: Extract data from receipts/documents to create Cash Vouchers or Dispute Letters.
Datasets: Use knowledge of LHDN Public Ruling No. 5/2021 (Deduction for Expenses) and Paragraph 82(1) ITA 1967.
Output format: JSON only.`;

export const analyzeVoucherInput = async (input: string | { base64: string, mimeType: string }): Promise<GeminiResponse> => {
  const model = 'gemini-3-flash-preview';
  
  const contents = typeof input === 'string' 
    ? { parts: [{ text: input }] }
    : {
        parts: [
          { inlineData: { data: input.base64, mimeType: input.mimeType } },
          { text: "Extract company details and transaction details for a cash voucher." }
        ]
      };

  const response: GenerateContentResponse = await ai.models.generateContent({
    model,
    contents,
    config: {
      systemInstruction: SYSTEM_INSTRUCTION,
      responseMimeType: "application/json",
      responseSchema: {
        type: Type.OBJECT,
        properties: {
          voucher_draft: {
            type: Type.OBJECT,
            properties: {
              voucherNumber: { type: Type.STRING },
              date: { type: Type.STRING },
              payee: { type: Type.STRING },
              amount: { type: Type.NUMBER },
              description: { type: Type.STRING },
              category: { type: Type.STRING }
            },
            required: ["amount", "payee", "description"]
          },
          business_info: {
            type: Type.OBJECT,
            properties: {
              name: { type: Type.STRING },
              address: { type: Type.STRING },
              regNumber: { type: Type.STRING }
            }
          },
          compliance_check: {
            type: Type.OBJECT,
            properties: {
              is_compliant: { type: Type.BOOLEAN },
              notes: { type: Type.STRING }
            },
            required: ["is_compliant"]
          },
          tax_relief_summary: {
            type: Type.OBJECT,
            properties: {
              eligible: { type: Type.BOOLEAN },
              savings_est: { type: Type.NUMBER },
              reasoning: { type: Type.STRING }
            }
          },
          recommendations: {
            type: Type.ARRAY,
            items: { type: Type.STRING }
          }
        },
        required: ["voucher_draft", "compliance_check", "tax_relief_summary"]
      }
    }
  });

  return JSON.parse(response.text || '{}') as GeminiResponse;
};

export const draftDisputeLetter = async (reason: string, businessName: string, amount: number): Promise<DisputeResponse> => {
  const model = 'gemini-3-pro-preview';
  const response = await ai.models.generateContent({
    model,
    contents: `Draft a formal LHDN Lost Receipt Dispute Letter for ${businessName}. Reason: ${reason}. Amount involved: RM ${amount}. Refer to ITA 1967 and relevant Public Rulings.`,
    config: {
      systemInstruction: "You are a Malaysian Tax Attorney. Draft professional A4 format letters for IRB submissions.",
      responseMimeType: "application/json",
      responseSchema: {
        type: Type.OBJECT,
        properties: {
          letter_content: { type: Type.STRING },
          legal_references: { type: Type.ARRAY, items: { type: Type.STRING } },
          compliance_score: { type: Type.NUMBER }
        },
        required: ["letter_content"]
      }
    }
  });
  return JSON.parse(response.text || '{}') as DisputeResponse;
};
